# Day 1 - Hello AI

调用 OpenAI API，返回简单问答示例。

运行:

```
python hello_ai.py
```