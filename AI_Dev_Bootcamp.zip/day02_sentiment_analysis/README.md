# Day 2 - 文本情感分析

使用简易的IMDb影评样本做情感分类。

运行:

```
python sentiment.py
```