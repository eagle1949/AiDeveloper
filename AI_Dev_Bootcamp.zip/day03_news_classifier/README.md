# Day 3 - 新闻分类

使用简易 AG News 子集做文本分类演示。

运行:

```
python news_classifier.py
```