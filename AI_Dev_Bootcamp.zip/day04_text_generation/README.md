# Day 4 - 文本生成

使用 OpenAI GPT API 生成文本。

运行:

```
python text_gen.py
```