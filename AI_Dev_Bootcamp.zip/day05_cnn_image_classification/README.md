# Day 5 - 简单 CNN 图像分类

使用 PyTorch 实现 CIFAR-10 子集上的简单卷积神经网络。

运行:

```
python cnn_train.py
```