# Day 6 - 语音转文字

使用 OpenAI Whisper API 进行短语音转录。

运行:

```
python speech_to_text.py
```