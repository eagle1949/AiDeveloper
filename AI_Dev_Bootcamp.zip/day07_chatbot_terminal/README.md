# Day 7 - 终端聊天机器人

使用 OpenAI API 实现简单多轮聊天。

运行:

```
python chatbot.py
```