# Day 8 - 文本摘要

使用 OpenAI API 进行文本摘要演示。

运行:

```
python summarization.py
```