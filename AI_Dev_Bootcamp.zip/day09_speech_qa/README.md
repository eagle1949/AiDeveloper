# Day 9 - 语音问答

实现语音输入和文本问答的结合。

运行:

```
python speech_qa.py
```