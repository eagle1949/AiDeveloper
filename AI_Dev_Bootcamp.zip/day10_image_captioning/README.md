# Day 10 - 图片描述生成

使用简单的图片描述模型。

运行:

```
python image_caption.py
```