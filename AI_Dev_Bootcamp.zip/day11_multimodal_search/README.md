# Day 11 - 多模态搜索

示例展示文本和图片的向量检索基础。

运行:

```
python multimodal_search.py
```