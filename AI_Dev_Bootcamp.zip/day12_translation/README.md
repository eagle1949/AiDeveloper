# Day 12 - 机器翻译

使用 OpenAI 翻译 API 演示。

运行:

```
python translation.py
```