# Day 14 - Streamlit 综合应用

用 Streamlit 搭建简单聊天 UI。

运行:

```
streamlit run streamlit_app.py
```